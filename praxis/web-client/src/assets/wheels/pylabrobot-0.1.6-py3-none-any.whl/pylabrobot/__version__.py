"""Definition file for various version numbers."""

# Version number for pylabrobot
__version__ = "0.1.6"

# Version number of the standard form protocol used by the server.
STANDARD_FORM_JSON_VERSION = "0.1.0"
