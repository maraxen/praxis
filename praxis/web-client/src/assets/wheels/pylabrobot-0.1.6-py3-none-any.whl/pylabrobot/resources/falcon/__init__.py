raise NotImplementedError(
  "pylabrobot.resources.falcon is deprecated. Please use pylabrobot.resources.corning.falcon instead."
)
