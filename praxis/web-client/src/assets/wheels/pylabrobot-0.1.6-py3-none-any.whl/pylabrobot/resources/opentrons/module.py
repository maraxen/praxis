class OTModule:
  """Any ot module like temperature controller, thermocycler, etc."""
