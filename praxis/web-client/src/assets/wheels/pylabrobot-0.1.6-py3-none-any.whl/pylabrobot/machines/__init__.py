from .machine import Machine, need_setup_finished
