from typing import Any, Dict, List

from pylabrobot.liquid_handling.backends.backend import (
  LiquidHandlerBackend,
)
from pylabrobot.resources import Tip


class SaverBackend(LiquidHandlerBackend):
  """A backend that saves all commands received in a list, for testing purposes."""

  def __init__(self, num_channels: int, *args, **kwargs):
    super().__init__(*args, **kwargs)
    self.commands_received: List[Dict[str, Any]] = []
    self._num_channels = num_channels

  @property
  def num_channels(self) -> int:
    return self._num_channels

  async def setup(self):
    await super().setup()
    self.commands_received = []

  async def stop(self):
    pass

  def serialize(self) -> dict:
    return {**super().serialize(), "num_channels": self.num_channels}

  async def send_command(self, command: str, data: Dict[str, Any]):
    self.commands_received.append({"command": command, "data": data})

  async def pick_up_tips(self, *args, **kwargs):
    self.commands_received.append({"command": "pick_up_tips", "args": args, "kwargs": kwargs})

  async def drop_tips(self, *args, **kwargs):
    self.commands_received.append({"command": "drop_tips", "args": args, "kwargs": kwargs})

  async def aspirate(self, *args, **kwargs):
    self.commands_received.append({"command": "aspirate", "args": args, "kwargs": kwargs})

  async def dispense(self, *args, **kwargs):
    self.commands_received.append({"command": "dispense", "args": args, "kwargs": kwargs})

  async def pick_up_tips96(self, *args, **kwargs):
    self.commands_received.append({"command": "pick_up_tips96", "args": args, "kwargs": kwargs})

  async def drop_tips96(self, *args, **kwargs):
    self.commands_received.append({"command": "drop_tips96", "args": args, "kwargs": kwargs})

  async def aspirate96(self, *args, **kwargs):
    self.commands_received.append({"command": "aspirate96", "args": args, "kwargs": kwargs})

  async def dispense96(self, *args, **kwargs):
    self.commands_received.append({"command": "dispense96", "args": args, "kwargs": kwargs})

  async def pick_up_resource(self, *args, **kwargs):
    self.commands_received.append({"command": "pick_up_resource", "args": args, "kwargs": kwargs})

  async def move_picked_up_resource(self, *args, **kwargs):
    self.commands_received.append(
      {"command": "move_picked_up_resource", "args": args, "kwargs": kwargs}
    )

  async def drop_resource(self, *args, **kwargs):
    self.commands_received.append({"command": "drop_resource", "args": args, "kwargs": kwargs})

  def can_pick_up_tip(self, channel_idx: int, tip: Tip) -> bool:
    return True

  # Saver specific methods

  def clear(self):
    self.commands_received = []

  def get_commands_for_event(self, event: str) -> List[Dict[str, Any]]:
    return [command for command in self.commands_received if command["command"] == event]
