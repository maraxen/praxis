from pylabrobot.scales.mettler_toledo_backend import MettlerToledoWXS205SDU
from pylabrobot.scales.scale import Scale
