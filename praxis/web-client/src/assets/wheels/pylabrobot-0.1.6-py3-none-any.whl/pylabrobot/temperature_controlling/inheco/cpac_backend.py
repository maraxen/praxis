from pylabrobot.temperature_controlling.inheco.temperature_controller import (
  InhecoTemperatureControllerBackend,
)


class InhecoCPACBackend(InhecoTemperatureControllerBackend):
  pass
