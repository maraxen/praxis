class NotCalibratedError(Exception):
  """Error raised when calling a method that requires the pump to be calibrated."""
